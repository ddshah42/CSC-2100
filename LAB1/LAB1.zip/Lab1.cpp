/*
	File Name: lab1.cpp
	Author: Dhairya Shah
	Date: January 21 , 2016
	Purpose: My first C++ program!
*/

#include<iostream>
using namespace std;

int main()
{
	cout<<endl;
	cout<<"Hello, my name is Dhairya.\n\n";
	cout<<"This is my first lab in CSC2101!\n\n";
	
	return 0;
	
}	
	