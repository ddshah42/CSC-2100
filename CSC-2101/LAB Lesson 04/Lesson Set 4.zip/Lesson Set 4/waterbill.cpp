/*
	Title:  grades.cpp
	Author: Rezvi Ahmed
	Date:   02/12/2015
	Purpose:	This program prompts the user for their quarterly water bill for the last four quarters and it prints the average monthly water bill. Also it prints a message according to the users water bill.
 */


#include <iostream>
using namespace std;

int main()
{

    float average;      //holds average monthly water bill.
    float quarter1;     //bill for the quarter 1
    float quarter2;     //bill for the quarter 2
    float quarter3;     //bill for the quarter 3
    float quarter4;     //bill for the quarter 4
	
	cout << "Please input your water bill for quarter 1:\n";      //prompts to ask for the quarter 1 bill.
    cin >> quarter1;
    cout << "\nPlease input your water bill for quarter 2:\n";    //prompts to ask for the quarter 2 bill.
	cin >> quarter2;
    cout << "\nPlease input your water bill for quarter 3:\n";    //prompts to ask for the quarter 3 bill.
	cin >> quarter3;
    cout << "\nPlease input your water bill for quarter 4:\n";    //prompts to ask for the quarter 4 bill.
	cin >> quarter4;
	
	average = (quarter1 + quarter2 + quarter3 + quarter4)/12;     //computes the average.
	cout << "Your average monthly bill is " << average << ".\n";
	
	
	if(average > 75)
		cout << "You are using excessive amounts of water.\n\n";
	else if (average >= 25 && average < 75)
		cout << "You are using a typical amount of water.\n\n";
	else if (average > 0 && average <25)
		cout << "Thank you for conserving water!\n\n";
			
			
		return 0;
		
}