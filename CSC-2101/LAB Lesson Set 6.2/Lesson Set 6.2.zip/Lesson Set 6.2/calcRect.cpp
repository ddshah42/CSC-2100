/*
	Title:  calcRect.cpp
	Author: Rezvi Ahmed
	Date:	03/19/2015
	Purpose:  Calculate the area & perimeter of a rectangle
*/

//Function prototype for calculateRectangle


#include <iostream>
using namespace std;

void calculateRectangle(float&, float&, float, float);
int main()
{
	float area, perimeter, height, width;
		
	//get user input
	cout << "\n\nEnter the height & width of the rectangle separated by a space.\n";
	cin >> height >> width;
	
	//call calculateRectangle
	calculateRectangle (area, perimeter, height, width);
	
	//Print out the resulting area & perimeter
	cout << "The are of your rectangle is " << area << endl;
	cout << "The perimeter of your rectangle is " << perimeter << endl << endl;
	
	
	return 0;
}

//function header for calculateRectangle
void calculateRectangle (float& area, float& perimeter, float height, float width)
{
	//calculate area & perimeter
	area = height * width;
	perimeter = 2 * (height + width);
	
	
}