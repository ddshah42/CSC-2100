/*
	Title:  paycheck.cpp
	Author: Rezvi Ahmed
	Date:	03/19/2015
	Purpose:
		This program converts miles to kilometers and kilometers to miles.
*/

#include<iostream>

using namespace std;

float milesToKilos(float);
float kilosToMiles(float);

int main()
{
	int menuOption;
	float miles, kilos;
	do 
	{
		cout << "Please input\n";
		cout << "1 Convert miles to kilometers\n";
		cout << "2 Convert kilometers to miles\n";
		cout << "3 Quit\n";
		cin >> menuOption;
		
		switch (menuOption)
		{
			case 1:
			{
				cout << "Please input the miles to be converted\n";
				cin >> miles;
				kilos = milesToKilos(miles);
				cout << miles << " miles = " << kilos << " kilometers\n\n";
				break;
			}		
			case 2:
			{
				cout << "Please input the kilometers to be converted\n";
				cin >> kilos;
				miles = kilosToMiles(kilos);
				cout << kilos << " kilometers = " << miles << " miles\n\n";
				break;
			}		
			case 3: 
				cout << "You chose to quit.\n";
				break;
			
			default:cout << "Invalid input\n\n";
		}
	}while(menuOption != 3);
	
	return 0;
}


float milesToKilos(float miles)
{
	return miles * 1.61; 
}

float kilosToMiles(float kilos)
{
	return kilos * .621; 
}