#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

struct Pet
{
	string petName;
	string description;
	int age;
	bool dangerous;
};

float convertToFloat(string);

int main()
{
	Pet myPets[50];
	int curNumPets = 0; //this is the current number of pets placed in the array (starts with zero)
	ifstream inFile;
	char filename[26];
	string numberReadFromFile; //use this when reading a number from the file
	string horizontalLine(25,'-');
	string tempString;
	
	
	
	cout << "\n\nPlease enter the name of the file that contains your pet data:  ";
	cin.getline(filename, 26);
	
	inFile.open(filename);
	if(inFile)
	{
		getline(inFile, tempString, '$');  //read the first pet name from the file
		
		while(!inFile.eof()) //while we are not at the end of file
		{
			myPets[curNumPets].petName = tempString; //put the name of the pet inside the array petName member
			getline(inFile, myPets[curNumPets].description, '$');  //read description from file
			
			getline(inFile, numberReadFromFile, '$'); //read in the pets age from the file
			myPets[curNumPets].age = convertToFloat(numberReadFromFile); //convert the string to a float and then place in structure array
			
			getline(inFile, numberReadFromFile, '$'); //read in whether the pet is dangerous or not (1 means yes, 0 means no)
			myPets[curNumPets].dangerous = convertToFloat(numberReadFromFile); //convert the string to a float and then place in structure array
			
			curNumPets++; //move on to the next array element to start entering next pet info
			
			getline(inFile, tempString, '$');  //read the next pet name from the file	
		}
		
		//print out the data to the screen
		for(int x=0; x<curNumPets; x++)
		{
			cout << "\n\nPET NAME:  " << myPets[x].petName << endl;
			cout << "\nDESCRIPTION:  " << myPets[x].description << endl;
			cout << "\nAGE: " << myPets[x].age << endl;
			if(myPets[x].dangerous == 0)
				cout << "\nDANGEROUS: no\n";
			else
				cout << "\nDANGEROUS: yes\n";
			cout << horizontalLine << endl;
		}
	}
	else
		cout << "File could not be opened.\n\n";
	
	return 0;
}

float convertToFloat(string s)
{
    istringstream i(s);
    float x;
    if (!(i >> x))
        x = 0;
    return x;
} 