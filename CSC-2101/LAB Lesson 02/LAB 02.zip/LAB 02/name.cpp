/*
	Title:  name.cpp
	Author: Rezvi Ahmed
	Date:   01/29/2015
	Purpose:  This proram will write the name, address and telephone number of the programmer.
*/

#include <iostream>
using namespace std;

int main()
{
    cout << "************" << endl;
    cout << "     Programmer: Rezvi Ahmed" << endl;
    cout << "                1801 Lee Ave. Apt B-27" << endl;
    cout << "                Cookeville, TN. 38501" << endl;
    cout << "\n\n     Telephone:  773-458-0849\n";
	cout << "************\n\n";
    
	return 0;
}